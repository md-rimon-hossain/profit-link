import mainLogo from "./logo.png";
import locus from "./locus.png";
import sreta from "./creta.png";



export {
    mainLogo,
    locus,
    sreta
}